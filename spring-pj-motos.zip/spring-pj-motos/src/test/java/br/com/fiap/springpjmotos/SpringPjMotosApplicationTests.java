package br.com.fiap.springpjmotos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringPjMotosApplicationTests {

    @Test
    void contextLoads() {
    }

}
