package br.com.fiap.springpjmotos.resource;


import br.com.fiap.springpjmotos.entity.Veiculo;
import br.com.fiap.springpjmotos.entity.Acessorio;
import br.com.fiap.springpjmotos.entity.Loja;
import br.com.fiap.springpjmotos.entity.TipoVeiculo;
import br.com.fiap.springpjmotos.repository.VeiculoRepository;
import br.com.fiap.springpjmotos.repository.AcessorioRepository;
import br.com.fiap.springpjmotos.repository.LojaRepository;
import br.com.fiap.springpjmotos.repository.TipoVeiculoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/Veiculos")
public class VeiculoResource {

    @Autowired
    private VeiculoRepository repo;

    @Autowired
    private AcessorioRepository acessorioRepository;

    @Autowired
    private LojaRepository lojaRepository;

    @Autowired
    private TipoVeiculoRepository tipoVeiculoRepository;

    @GetMapping
    public List<Veiculo> findAll() {
        return repo.findAll();
    }

    @GetMapping(value = "/{id}")
    public Veiculo findAll(@PathVariable("id") Long id) {
        var ret = repo.findById(id);
        return ret.get();
    }

    @Transactional
    @PostMapping
    public Veiculo persist(@RequestBody Veiculo veiculo) {
        return repo.save(veiculo);
    }

    @Transactional
    @PostMapping(value = "/{idVeiculo}/acessorio")
    public Acessorio persistAcessorio(@PathVariable("idVeiculo") Long idVeiculo, @RequestBody Acessorio acessorio) {
        Veiculo Veiculo = repo.findById(idVeiculo).orElseThrow();
        acessorio.setVeiculo(Veiculo);
        return acessorioRepository.save(acessorio);
    }

    @GetMapping(value = "/{idVeiculo}/acessorios")
    public List<Acessorio> getAcessorio(@PathVariable("idVeiculo") Long idVeiculo) {
        return acessorioRepository.findByVeiculoId(idVeiculo);
    }

    @GetMapping(value = "/{idVeiculo}/Lojas")
    public List<Loja> findByVeiculoId(@PathVariable("idVeiculo") Long idVeiculo) {
        return lojaRepository.findByVeiculoId(idVeiculo);
    }

    @Transactional
    @PostMapping(value = "/{idVeiculo}/Lojas")
    public Loja persistLoja(@PathVariable("idVeiculo") Long idVeiculo, @RequestBody Loja Loja) {
        Veiculo Veiculo = repo.findById(idVeiculo).orElseThrow();
        Loja.setVeiculo(Veiculo);
        return lojaRepository.save(Loja);
    }

    @GetMapping(value = "/{idVeiculo}/Lojas")
    public List<TipoVeiculo> getTipoVeiculos(@PathVariable("idVeiculo") Long idVeiculo) {
        return tipoVeiculoRepository.findByVeiculoId(idVeiculo);
    }

    @Transactional
    @PostMapping(value = "/{idVeiculo}/Lojas")
    public Loja persistTipoVeiculo(@PathVariable("idVeiculo") Long idVeiculo, @RequestBody Loja Loja) {
        Veiculo Veiculo = repo.findById(idVeiculo).orElseThrow();
        Loja.setVeiculo(Veiculo);
        return lojaRepository.save(Loja);
    }

}