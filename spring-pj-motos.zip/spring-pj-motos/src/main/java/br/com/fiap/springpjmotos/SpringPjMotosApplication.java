package br.com.fiap.springpjmotos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringPjMotosApplication {

    public static void main(String[] args) {
        SpringApplication.run( SpringPjMotosApplication.class, args );
    }

}
