package br.com.fiap.springpjmotos.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "TB_ACESSORIO")
public class Acessorio {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
                    generator = "SQ_ACESSORIO")
    @SequenceGenerator(
            name = "SQ_ACESSORIO",
            sequenceName = "SQ_ACESSORIO",
            initialValue = 1,
            allocationSize = 1)
    @Column(name = "ID_ACESSORIO")
    private Long id;

    @Column(name = "NOME_ACESSORIO")
    private String nome;

    @Column(name = "PRECO_ACESSORIO")
    private Double preco;

    @ManyToMany
    @JoinColumn(
            name = "VEICULO",
            referencedColumnName = "ID_VEICULO",
            foreignKey = @ForeignKey(name = "FK_VEICULO")
    )
    private Veiculo veiculo;

}
