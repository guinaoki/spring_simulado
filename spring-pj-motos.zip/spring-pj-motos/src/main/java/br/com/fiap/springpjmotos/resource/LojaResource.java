package br.com.fiap.springpjmotos.resource;

import br.com.fiap.springpjmotos.entity.Loja;
import br.com.fiap.springpjmotos.repository.LojaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RequestMapping(value = "/loja")
@RestController
public class LojaResource {

    @Autowired
    private LojaRepository repo;

    @GetMapping(value = "/{idVeiculo}")
    public List<Loja> findByIdVeiculo(@PathVariable Long idVeiculo) {
        return repo.findByVeiculoId(idVeiculo);
    }

}