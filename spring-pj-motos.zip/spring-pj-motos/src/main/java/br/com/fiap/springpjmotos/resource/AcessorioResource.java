package br.com.fiap.springpjmotos.resource;

import br.com.fiap.springpjmotos.entity.Acessorio;
import br.com.fiap.springpjmotos.repository.AcessorioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RequestMapping(value = "/acessorio")
@RestController
public class AcessorioResource {

    @Autowired
    private AcessorioRepository repo;

    @GetMapping(value = "/{idVeiculo}")
    public List<Acessorio> findByVeiculoId(@PathVariable Long idVeiculo) {
        return repo.findByVeiculoId(idVeiculo);
    }

}